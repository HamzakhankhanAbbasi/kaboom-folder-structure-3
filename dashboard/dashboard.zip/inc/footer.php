<footer>
  <p>© 2021 KaboomCollab All Rights Reserved</p>
</footer>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/owl.carousel.min.js"></script>
  <script src="assets/js/aos.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.3.0/dropzone.js"></script>
  <script src="//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
  <script src="assets/js/custom.js"></script>
  <script>
  AOS.init();
</script>
<script>
	tinymce.init({
		selector: '#editor-cat-repl',
		menubar: false,
		statusbar: false,
		min_height: 200,
		font_formats: "Arial Black=arial black,avant garde; Courier New=courier new,courier; Lato Black=lato; Roboto=roboto;",
		toolbar: "undo redo | styleselect | fontsizeselect | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | forecolor backcolor | fontselect ",
		plugins: "textcolor colorpicker",
	});
	</script>

	
</body>

</html>